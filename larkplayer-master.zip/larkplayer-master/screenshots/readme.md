### PC

<img alt="larkplayer pc" src="./larkplayer-pc.png" width="640" height="360" />


### Mobile

<img alt="larkplayer mobile" src="./larkplayer-mobile.png" width="640" height="360" />