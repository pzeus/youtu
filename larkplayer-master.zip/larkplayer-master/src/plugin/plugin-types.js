/**
 * @file plugin-types 定义插件类型
 * @author yuhui06
 * @date 2018/4/8
 */


export default {
    UI: 'UI',
    MS: 'MS',
    OTHERS: 'plugin'
};