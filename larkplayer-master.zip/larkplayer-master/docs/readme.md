

* [design](./design.md)
* api
    * [Player](./api/player.md)
    * [Events](./api/events.md)
    * [DOM](./api/dom.md)
* plugin example
    * [UI Plugin](./plugin/ui-plugin-example.md)
    * [MS Plugin](./plugin/media-source-plugin-example.md)
    * [Normal Plugin](./plugin/normal-plugin-example.md)
