目前有 3 种插件，编写示例如下：

* UI 插件，[编写示例](./ui-plugin-example.md)
* MediaSource 插件，基于 MSE 提供更多视频格式支持，[编写示例](./media-source-plugin-example.md)
* Plugin 其他插件，[编写示例](./normal-plugin-example.md)
