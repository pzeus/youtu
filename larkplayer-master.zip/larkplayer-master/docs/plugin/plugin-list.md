larkplayer 目前拥有以下插件：

* [larkplayer-ui](https://github.com/dblate/larkplayer-ui)，提供适应 pc 与移动端的样式
* [larkplayer-hls](https://github.com/dblate/larkplayer-hls)， 支持 m3u8 视频播放
* [larkplayer-vr](https://github.com/dblate/larkplayer-vr)，支持 vr（全景）视频播放

如果你想要分享自己开发的插件，请通过邮箱（173983476@qq.com）或者 issue 联系我，十分欢迎 👏 

如何编写插件请点击[这里](./readme.md)
