<a name="newGUID"></a>

## newGUID() ⇒ <code>number</code>
获取一个自增且唯一的 ID

**Kind**: global function  
**Returns**: <code>number</code> - 新的 ID  
