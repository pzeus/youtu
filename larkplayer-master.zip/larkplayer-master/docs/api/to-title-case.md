<a name="toTitleCase"></a>

## toTitleCase(str) ⇒ <code>string</code>
将字符串的首字母大写

**Kind**: global function  
**Returns**: <code>string</code> - 首字母大写的字符串  

| Param | Type | Description |
| --- | --- | --- |
| str | <code>string</code> | 要将首字母大写的字符串 |

